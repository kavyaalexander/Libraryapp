function validate(uid, mx, my) {
    let userid = document.getElementById("userid").value;
    let label = document.getElementById("check");
    var uid_len = uid.value.length;

    if (uid_len == 0 || uid_len >= my || uid_len < mx) {
        label.innerHTML = "Valid";
        label.style.color = "Green";
        label.style.visibility = "visible";
        return true;

    } else {
        label.innerHTML = "Invalid";
        label.style.color = "red";
        label.style.visibility = "visible";
        return false;

    }
}



function validatePassword() {
    let pwd = document.getElementById("pwd").value;
    let label = document.getElementById("find");
    let regexp = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
    if (regexp.passwrd(pwd)) {
        label.innerHTML = "Valid";
        label.style.color = "Green";
        label.style.visibility = "visible";
        return true;

    } else {
        label.innerHTML = "Invalid";
        label.style.color = "red";
        label.style.visibility = "visible";
        return false;


    }
}